# 这是示例程序SampleDetector所依赖的软件

开发自己的程序时，请删除主编译文件`/usr/local/ev_sdk/CMakeLists.txt`中对于该库的依赖。