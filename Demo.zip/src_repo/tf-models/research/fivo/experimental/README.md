An experimental codebase for running simple examples.
