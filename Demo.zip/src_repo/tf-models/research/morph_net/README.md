# MorphNet project has moved to https://github.com/google-research/morph-net.

**This directory contains the deprecated version of MorphNet. Please use the [new repo](https://github.com/google-research/morph-net).**
